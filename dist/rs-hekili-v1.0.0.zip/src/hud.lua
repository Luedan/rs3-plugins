local Abilities = require("src/abilities")
local Engine = require("src/engine")
local Settings = require("src/settings")

local HUD = {}

local hudLayer = nil
local slots = {}

-- Configuración visual de las ranuras (Slot 1 grande, Slots 2 y 3 proyectadas)
local SLOT_CONFIGS = {
    { size = 62, iconPadding = 3, borderWidth = 2, borderColor = 0xFFD700FF, isNext = true },
    { size = 48, iconPadding = 2, borderWidth = 1, borderColor = 0x64B5F6EE, isNext = false },
    { size = 40, iconPadding = 2, borderWidth = 1, borderColor = 0x90A4AEEE, isNext = false },
}

local function colourToVec4(colour)
    local c = tonumber(colour) or 0xFFFFFFFF
    local r = (c >> 24) & 0xFF
    local g = (c >> 16) & 0xFF
    local b = (c >> 8) & 0xFF
    local a = c & 0xFF
    return Vector4.new(r / 255, g / 255, b / 255, a / 255)
end

--- Obtiene el recurso de imagen de Plugin.resources.icons de forma segura
local function getIconResource(iconFile)
    if not Plugin or not Plugin.resources or not Plugin.resources.icons then
        return nil
    end
    local icons = Plugin.resources.icons
    return icons[iconFile] or icons[iconFile .. ".png"]
end

function HUD.Create(gameArea)
    if not gameArea then
        log("No se pudo obtener GAME_AREA para montar el HUD.")
        return false
    end

    if hudLayer then
        HUD.Destroy()
    end

    -- Capa raíz centrada en medio de la pantalla (50% X, 50% Y)
    local totalWidth = 62 + 8 + 48 + 8 + 40
    hudLayer = ui.Layer.new(gameArea)
    -- Posición: 50% horizontal, 50% vertical en el medio de la pantalla
    hudLayer:SetPos(Settings.data.posX, Settings.data.posY, 0.5, 0.50, -0.5, -0.5)
    hudLayer:SetSize(totalWidth, 75)

    slots = {}
    local currentX = 0

    for i = 1, #SLOT_CONFIGS do
        local cfg = SLOT_CONFIGS[i]
        local slotData = {}
        local yOffset = 62 - cfg.size -- Alinear por la base inferior

        -- 1. Fondo oscuro translúcido
        slotData.bg = ui.Rectangle.new(hudLayer)
        slotData.bg:SetPos(currentX, yOffset)
        slotData.bg:SetSize(cfg.size, cfg.size)
        slotData.bg.colour = colourToVec4(0x0A0F1AEE)

        -- 2. Icono oficial de la habilidad (ui.Sprite)
        slotData.iconSprite = ui.Sprite.new(hudLayer)
        slotData.iconSprite:SetPos(currentX + cfg.iconPadding, yOffset + cfg.iconPadding)
        slotData.iconSprite:SetSize(cfg.size - (cfg.iconPadding * 2), cfg.size - (cfg.iconPadding * 2))

        -- 3. Borde elegante con resalte dorado en la ranura principal
        slotData.border = ui.Rectangle.new(hudLayer)
        slotData.border:SetPos(currentX, yOffset)
        slotData.border:SetSize(cfg.size, cfg.size)
        slotData.border.colour = colourToVec4(cfg.borderColor)
        slotData.border.fill = false
        slotData.border.outlineThickness = -cfg.borderWidth

        -- 4. Placa de fondo para la tecla de atajo
        local badgeW = 20
        local badgeH = 16
        slotData.keyBg = ui.Rectangle.new(hudLayer)
        slotData.keyBg:SetPos(currentX + cfg.size - badgeW, yOffset + cfg.size - badgeH)
        slotData.keyBg:SetSize(badgeW, badgeH)
        slotData.keyBg.colour = colourToVec4(0x000000CC)

        -- 5. Texto de tecla asignada (ej: "1", "2", "3")
        slotData.keyText = ui.Text.new(hudLayer)
        slotData.keyText:SetPos(currentX + cfg.size - badgeW + 2, yOffset + cfg.size - badgeH)
        slotData.keyText:SetSize(badgeW - 2, badgeH)
        slotData.keyText.colour = colourToVec4(0xFFEE00FF) -- Amarillo brillante visible
        slotData.keyText.content = ""

        -- 6. Etiqueta "NEXT" sobre la ranura principal
        if cfg.isNext then
            slotData.nextBadge = ui.Text.new(hudLayer)
            slotData.nextBadge:SetPos(currentX + 2, yOffset - 12)
            slotData.nextBadge:SetSize(cfg.size, 12)
            slotData.nextBadge.colour = colourToVec4(0xFFD700FF)
            slotData.nextBadge.content = ">> SIGUIENTE <<"
        end

        slots[i] = slotData
        currentX = currentX + cfg.size + 8
    end

    log(string.format("HUD de Hekili montado en pantalla [Centro X: 50%%, Y: 50%%]."))
    return true
end

function HUD.Update()
    if not hudLayer then return end

    if Settings.data.hideOutOfCombat and not Engine.IsInCombat() then
        hudLayer.hidden = true
        return
    else
        hudLayer.hidden = false
    end

    local queue = Engine.CalculateQueue(#slots)

    for i = 1, #slots do
        local slot = slots[i]
        local ability = queue[i]

        if ability then
            -- Cargar icono real de la habilidad
            local iconRes = getIconResource(ability.iconFile)
            if iconRes then
                slot.iconSprite.sprite = iconRes
                slot.iconSprite.hidden = false
            else
                slot.iconSprite.hidden = true
            end

            -- Mostrar tecla de atajo
            local keybind = Settings.GetKeybind(ability.id)
            slot.keyText.content = keybind

            -- Visibilidad de elementos
            slot.bg.hidden = false
            slot.border.hidden = false
            slot.keyBg.hidden = false
            slot.keyText.hidden = false
            if slot.nextBadge then slot.nextBadge.hidden = false end
        else
            slot.bg.hidden = true
            slot.iconSprite.hidden = true
            slot.border.hidden = true
            slot.keyBg.hidden = true
            slot.keyText.hidden = true
            if slot.nextBadge then slot.nextBadge.hidden = true end
        end
    end
end

function HUD.Destroy()
    if hudLayer then
        pcall(function()
            hudLayer.hidden = true
        end)
        hudLayer = nil
        slots = {}
    end
end

return HUD
