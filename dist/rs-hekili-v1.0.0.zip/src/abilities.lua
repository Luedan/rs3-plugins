local Abilities = {}

--- Definición de habilidades mágicas con sus requisitos, tiempos de enfriamiento y colores.
Abilities.List = {
    wrack = {
        id = "wrack",
        name = "Wrack",
        shortName = "WRACK",
        level = 1,
        type = "basic",
        cooldownTicks = 5, -- 3 segundos (5 ticks)
        adrenalineGain = 8,
        description = "Daño base 94%. ¡Hace 188% si el objetivo está aturdido!",
        color = 0x1E88E5FF,     -- Azul mágico
        bgColour = 0x0D2B45EE,
        defaultKey = "3",       -- Coincide con tu barra de acción actual
        iconFile = "wrack",
    },
    sonic_wave = {
        id = "sonic_wave",
        name = "Sonic Wave",
        shortName = "SONIC",
        level = 12,
        type = "basic",
        cooldownTicks = 8, -- 5 segundos (~8 ticks)
        adrenalineGain = 8,
        description = "Daño 157% + 6% puntería al siguiente ataque",
        color = 0x00E5FFFF,     -- Cian sónico
        bgColour = 0x003B46EE,
        defaultKey = "1",       -- Coincide con tu barra de acción actual
        iconFile = "sonic_wave",
    },
    impact = {
        id = "impact",
        name = "Impact",
        shortName = "IMPACT",
        level = 15,
        type = "basic",
        cooldownTicks = 25, -- 15 segundos (25 ticks)
        adrenalineGain = 8,
        stuns = true,
        stunDurationTicks = 3, -- ~1.8s stun
        description = "Aturde por 1.2s e inmoviliza. ¡Prepara combo con Wrack!",
        color = 0xBA68C8FF,     -- Púrpura aturdimiento
        bgColour = 0x3E1B4DEE,
        defaultKey = "2",
        iconFile = "impact",
    },
    dragon_breath = {
        id = "dragon_breath",
        name = "Dragon Breath",
        shortName = "D-BREATH",
        level = 18,
        type = "basic",
        cooldownTicks = 17, -- 10 segundos (~17 ticks)
        adrenalineGain = 8,
        description = "Gran ráfaga de fuego en área (188% daño).",
        color = 0xFF5722FF,     -- Naranja fuego
        bgColour = 0x4D1A0DEE,
        defaultKey = "4",
        iconFile = "dragon_breath",
    },
    combust = {
        id = "combust",
        name = "Combust",
        shortName = "COMBUST",
        level = 34,
        type = "basic",
        cooldownTicks = 25, -- 15 segundos
        adrenalineGain = 8,
        description = "Sangrado continuo por 6s (doble si el objetivo se mueve).",
        color = 0xFFB300FF,     -- Ámbar fuego
        bgColour = 0x4D3600EE,
        defaultKey = "5",
        iconFile = "combust",
    },
    chain = {
        id = "chain",
        name = "Chain",
        shortName = "CHAIN",
        level = 45,
        type = "basic",
        cooldownTicks = 17, -- 10 segundos
        adrenalineGain = 8,
        description = "Golpea al objetivo y encadena a 2 enemigos cercanos.",
        color = 0x26C6DAFF,     -- Turquesa relámpago
        bgColour = 0x0A373DEE,
        defaultKey = "6",
        iconFile = "chain",
    },
    asphyxiate = {
        id = "asphyxiate",
        name = "Asphyxiate",
        shortName = "ASPHYX",
        level = 45,
        type = "threshold",
        cooldownTicks = 33, -- 20 segundos
        adrenalineReq = 50,
        adrenalineCost = 15,
        description = "Umbral: Canaliza 4 golpes fuertes y aturde.",
        color = 0x7E57C2FF,     -- Violeta oscuro
        bgColour = 0x2B1A4DEE,
        defaultKey = "Q",
        iconFile = "asphyxiate",
    },
    wild_magic = {
        id = "wild_magic",
        name = "Wild Magic",
        shortName = "W-MAGIC",
        level = 55,
        type = "threshold",
        cooldownTicks = 33, -- 20 segundos
        adrenalineReq = 50,
        adrenalineCost = 15,
        description = "Umbral: 2 impactos devastadores de magia pura.",
        color = 0xEC407AFF,     -- Rosa arcano
        bgColour = 0x4D0D2DEE,
        defaultKey = "E",
        iconFile = "wild_magic",
    },
}

--- Devuelve la lista ordenada por prioridad base
Abilities.PriorityOrder = {
    "asphyxiate",
    "wild_magic",
    "dragon_breath",
    "combust",
    "impact",
    "sonic_wave",
    "chain",
    "wrack",
}

return Abilities
