local Abilities = require("src/abilities")

local Engine = {}

local cooldowns = {}        -- abilityId -> ticksRestantes
local stunTicksRemaining = 0
local targetInCombat = false
local currentMagicLevel = 1
local currentAdrenaline = 0 -- 0 a 100

local function queryPlayerMagicLevel()
    if not Player or not Player.IsAvailable or not Player.IsAvailable() then
        return 1
    end
    local level = nil
    -- Intentar obtener nivel con enum o id numérico (SkillType.MAGIC = 6)
    pcall(function()
        if SkillType and SkillType.MAGIC then
            level = Player.GetLevelGameplay(SkillType.MAGIC)
        end
    end)
    if not level then
        pcall(function() level = Player.GetLevelGameplay(6) end)
    end
    if not level then
        pcall(function() level = Player.GetLevelUncapped(6) end)
    end
    return level or 1
end

function Engine.Init()
    cooldowns = {}
    stunTicksRemaining = 0
    targetInCombat = false
    currentMagicLevel = queryPlayerMagicLevel()

    -- Suscribirse a los ticks del servidor (~600ms) para decrementar tiempos
    Event.ServerLogic.Subscribe("rs_hekili_ticks", function()
        -- 1. Actualizar nivel de magia del jugador
        local lvl = queryPlayerMagicLevel()
        if lvl and lvl > 0 then
            currentMagicLevel = lvl
        end

        -- 2. Decrementar cooldowns activos
        for id, ticks in pairs(cooldowns) do
            if ticks > 0 then
                cooldowns[id] = ticks - 1
            else
                cooldowns[id] = 0
            end
        end

        -- 3. Decrementar temporizador de aturdimiento sobre el objetivo
        if stunTicksRemaining > 0 then
            stunTicksRemaining = stunTicksRemaining - 1
        end

        -- 4. Comprobar si el objetivo está en combate
        if var and var.VarClient and var.VarClient["COMBATV2_TARGET_SIDE_PANEL_HEALTH"] then
            targetInCombat = (var.VarClient["COMBATV2_TARGET_SIDE_PANEL_HEALTH"].value or 0) > 0
        else
            targetInCombat = true -- Asumir listo si no hay var client
        end
    end)

    -- Escuchar transmisiones de variables de combate para detectar uso de habilidades
    if Event.VarTransmit then
        Event.VarTransmit.Subscribe("rs_hekili_vars", function(event)
            if not event or not event.var then return end
            local configName = event.var.configName or ""

            -- Si detectamos que se usó Impacto, activar ventana de aturdimiento para Wrack
            if string.find(configName, "IMPACT") and event.newValue ~= event.oldValue then
                cooldowns["impact"] = Abilities.List.impact.cooldownTicks
                stunTicksRemaining = Abilities.List.impact.stunDurationTicks
            elseif string.find(configName, "SONIC") and event.newValue ~= event.oldValue then
                cooldowns["sonic_wave"] = Abilities.List.sonic_wave.cooldownTicks
            elseif string.find(configName, "DRAGON") and event.newValue ~= event.oldValue then
                cooldowns["dragon_breath"] = Abilities.List.dragon_breath.cooldownTicks
            elseif string.find(configName, "COMBUST") and event.newValue ~= event.oldValue then
                cooldowns["combust"] = Abilities.List.combust.cooldownTicks
            end
        end)
    end

    log(string.format("Motor APL Hekili iniciado. Nivel Magia inicial: %d", currentMagicLevel))
end

function Engine.GetMagicLevel()
    return currentMagicLevel
end

function Engine.IsInCombat()
    return targetInCombat
end

function Engine.IsAvailable(abilityId)
    local ability = Abilities.List[abilityId]
    if not ability then return false end

    -- 1. Verificar si el nivel es suficiente
    if currentMagicLevel < ability.level then
        return false
    end

    -- 2. Verificar si está en enfriamiento
    local cd = cooldowns[abilityId] or 0
    if cd > 0 then
        return false
    end

    -- 3. Verificar adrenalina para Thresholds
    if ability.type == "threshold" and currentAdrenaline < (ability.adrenalineReq or 50) then
        return false
    end

    return true
end

--- Simula el uso de una habilidad (para adelantar la cola proyectada)
local function simulateUse(simCds, abilityId)
    local ab = Abilities.List[abilityId]
    if ab then
        simCds[abilityId] = ab.cooldownTicks
    end
end

--- Calcula la cola de próximas habilidades recomendadas (de 1 a maxCount)
function Engine.CalculateQueue(maxCount)
    maxCount = maxCount or 3
    local queue = {}

    -- Clon de cooldowns para proyectar el 2º y 3º turno sin alterar el estado real
    local simCds = {}
    for k, v in pairs(cooldowns) do
        simCds[k] = v
    end

    local simStunTicks = stunTicksRemaining

    for step = 1, maxCount do
        local chosen = nil

        -- REGLA APL 1: ¡Combo Impact -> Wrack!
        -- Si el objetivo está aturdido y Wrack está desbloqueado, priorizar Wrack (188% daño)
        if simStunTicks > 0 and currentMagicLevel >= Abilities.List.wrack.level and (simCds["wrack"] or 0) <= 0 then
            chosen = Abilities.List.wrack
        end

        -- REGLA APL 2: Umbrales (si se desbloquean a futuro: Asphyxiate o Wild Magic)
        if not chosen and currentMagicLevel >= 45 and (simCds["asphyxiate"] or 0) <= 0 then
            chosen = Abilities.List.asphyxiate
        end

        -- REGLA APL 3: Dragon Breath (máximo daño de área al llegar a nivel 18)
        if not chosen and currentMagicLevel >= 18 and (simCds["dragon_breath"] or 0) <= 0 then
            chosen = Abilities.List.dragon_breath
        end

        -- REGLA APL 4: Combust (sangrado continuo a nivel 34+)
        if not chosen and currentMagicLevel >= 34 and (simCds["combust"] or 0) <= 0 then
            chosen = Abilities.List.combust
        end

        -- REGLA APL 5: Impact (preparar aturdimiento y combo)
        if not chosen and currentMagicLevel >= 15 and (simCds["impact"] or 0) <= 0 then
            chosen = Abilities.List.impact
        end

        -- REGLA APL 6: Sonic Wave (+6% puntería y daño sólido)
        if not chosen and currentMagicLevel >= 12 and (simCds["sonic_wave"] or 0) <= 0 then
            chosen = Abilities.List.sonic_wave
        end

        -- REGLA APL 7: Chain (nivel 45+)
        if not chosen and currentMagicLevel >= 45 and (simCds["chain"] or 0) <= 0 then
            chosen = Abilities.List.chain
        end

        -- REGLA APL 8: Wrack (Relleno base)
        if not chosen and currentMagicLevel >= 1 then
            chosen = Abilities.List.wrack
        end

        if chosen then
            table.insert(queue, chosen)
            -- Simular avance en el tiempo: cooldown aplicado
            simulateUse(simCds, chosen.id)
            if chosen.stuns then
                simStunTicks = chosen.stunDurationTicks
            else
                simStunTicks = math.max(0, simStunTicks - 3) -- Avanzar 1 GCD (~3 ticks)
            end
            -- Decrementar cooldowns en 3 ticks (1 GCD) para la siguiente ranura
            for k, cd in pairs(simCds) do
                simCds[k] = math.max(0, cd - 3)
            end
        else
            break
        end
    end

    return queue
end

function Engine.Shutdown()
    pcall(function() Event.ServerLogic.Unsubscribe("rs_hekili_ticks") end)
    pcall(function() Event.VarTransmit.Unsubscribe("rs_hekili_vars") end)
end

return Engine
