local Abilities = require("src/abilities")

local Settings = {}

local DB_PREFIX = "rs_hekili_"

local function dbGet(key, defaultVal)
    if not PersistentDB then return defaultVal end
    local ok, val = pcall(function() return PersistentDB:Get(DB_PREFIX .. key) end)
    if ok and val ~= nil then return val end
    return defaultVal
end

local function dbSet(key, val)
    if not PersistentDB then return false end
    return pcall(function() return PersistentDB:Set(DB_PREFIX .. key, val) end)
end

-- Cargar ajustes con valores por defecto
Settings.data = {
    posX = dbGet("pos_x", 0),
    posY = dbGet("pos_y", 120),
    hideOutOfCombat = dbGet("hide_ooc", false),
    queueSize = dbGet("queue_size", 3),
    keybinds = {}
}

-- Inicializar atajos por defecto para cada habilidad
for id, ability in pairs(Abilities.List) do
    local savedKey = dbGet("key_" .. id, ability.defaultKey)
    Settings.data.keybinds[id] = savedKey
end

function Settings.GetKeybind(abilityId)
    return Settings.data.keybinds[abilityId] or "?"
end

function Settings.SetKeybind(abilityId, keyText)
    Settings.data.keybinds[abilityId] = keyText
    dbSet("key_" .. abilityId, keyText)
end

function Settings.SetPosition(x, y)
    Settings.data.posX = x
    Settings.data.posY = y
    dbSet("pos_x", x)
    dbSet("pos_y", y)
end

function Settings.SetHideOutOfCombat(enable)
    Settings.data.hideOutOfCombat = enable
    dbSet("hide_ooc", enable)
end

return Settings
