local Abilities = require("src/abilities")
local Engine = require("src/engine")
local Settings = require("src/settings")

local UI = {}

local CONTENT_KEY = "rs_hekili_content"
local SETTINGS_KEY = "rs_hekili_settings"

local contentView = nil
local settingsView = nil

local function renderContent(parent)
    if contentView then
        pcall(function() contentView:Destroy() end)
        contentView = nil
    end

    if prettyui and prettyui.SimpleView then
        contentView = prettyui.SimpleView.new(parent, {
            width = parent.width,
            height = parent.height
        })

        contentView:AddTitle("RS Hekili - Asistente de Rotación")
        contentView:AddText(string.format("Nivel de Magia detectado: %d", Engine.GetMagicLevel()))
        contentView:AddDivider()

        contentView:AddTitle("Habilidades Activas en tu Rotación:")
        for _, id in ipairs(Abilities.PriorityOrder) do
            local ab = Abilities.List[id]
            if ab then
                local status = ""
                if Engine.GetMagicLevel() >= ab.level then
                    status = string.format("[DESBLOQUEADA] %s (Nvl %d) -> Tecla: [%s]", ab.name, ab.level, Settings.GetKeybind(ab.id))
                else
                    status = string.format("[BLOQUEADA] %s (Requiere Nivel %d)", ab.name, ab.level)
                end
                contentView:AddText(status)
            end
        end

        contentView:AddDivider()
        contentView:AddText("El HUD flotante en pantalla te indica en tiempo real qué tecla presionar.")
        contentView:AddText("Configura tus atajos en 'Plugin Hub > Manage > RS Hekili'.")
    end
end

local function renderSettings(parent)
    if settingsView then
        pcall(function() settingsView:Destroy() end)
        settingsView = nil
    end

    if prettyui and prettyui.SimpleView then
        settingsView = prettyui.SimpleView.new(parent, {
            width = parent.width,
            height = parent.height
        })

        settingsView:AddTitle("Configuración de RS Hekili")
        settingsView:AddText("Asigna la tecla que tienes en tu barra de acción para cada habilidad:")
        settingsView:AddDivider()

        -- Opciones de visibilidad
        if settingsView.AddCheckboxButton then
            settingsView:AddCheckboxButton({
                {
                    text = "Ocultar HUD cuando estés fuera de combate",
                    value = "hide_ooc",
                    selected = Settings.data.hideOutOfCombat
                }
            }, {
                onChange = function(_, _, key, isSelected)
                    if key == "hide_ooc" then
                        Settings.SetHideOutOfCombat(isSelected)
                        log("Ajuste 'hideOutOfCombat': " .. tostring(isSelected))
                    end
                end
            })
        end

        settingsView:AddDivider()
        settingsView:AddTitle("Atajos de Teclado Actuales:")
        for _, id in ipairs(Abilities.PriorityOrder) do
            local ab = Abilities.List[id]
            if ab and Engine.GetMagicLevel() >= ab.level then
                settingsView:AddText(string.format("* %s: Tecla [%s] (%s)", ab.name, Settings.GetKeybind(ab.id), ab.description))
            end
        end
    end
end

function UI.Init()
    Event.ContentLayerReady.Subscribe(CONTENT_KEY, function(event)
        if event and event.component then
            renderContent(event.component)
        end
    end)

    Event.SettingsLayerReady.Subscribe(SETTINGS_KEY, function(event)
        if event and event.component then
            renderSettings(event.component)
        end
    end)
end

function UI.Shutdown()
    pcall(function() Event.ContentLayerReady.Unsubscribe(CONTENT_KEY) end)
    pcall(function() Event.SettingsLayerReady.Unsubscribe(SETTINGS_KEY) end)

    if contentView then
        pcall(function() contentView:Destroy() end)
        contentView = nil
    end
    if settingsView then
        pcall(function() settingsView:Destroy() end)
        settingsView = nil
    end
end

return UI
