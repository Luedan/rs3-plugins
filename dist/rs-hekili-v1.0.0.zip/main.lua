--- ============================================================================
--- Plugin: RS Hekili
--- Asistente de Rotación de Combate en Tiempo Real para RuneScape (EoC)
--- ============================================================================

local PLUGIN_TAG = "rs-hekili"
log(">>> Iniciando RS Hekili v1.0.0...")

local Engine = require("src/engine")
local HUD = require("src/hud")
local UI = require("src/ui")

-- 1. Inicializar el motor APL de rotación y la interfaz de configuración
Engine.Init()
UI.Init()

-- 2. Montar el HUD en el área de juego
local gameArea = ui.Interfaces:GetComponent(id.Component.TOPLEVEL_V2__GAME_AREA)
if gameArea then
    HUD.Create(gameArea)
else
    log("Aviso: GAME_AREA no estaba disponible de inmediato; se reintentará en el primer tick.")
end

-- 3. Bucle de actualización en cada tick del juego (ServerLogic / Logic)
local UPDATE_KEY = "rs_hekili_update"
Event.ServerLogic.Subscribe(UPDATE_KEY, function()
    -- Reintentar montar el HUD si aún no existía
    if not gameArea then
        gameArea = ui.Interfaces:GetComponent(id.Component.TOPLEVEL_V2__GAME_AREA)
        if gameArea then
            HUD.Create(gameArea)
        end
    end

    -- Actualizar los iconos y la cola del HUD
    HUD.Update()
end)

log(string.format(">>> RS Hekili activo. Magia Nvl %d detectada.", Engine.GetMagicLevel()))

--- ============================================================================
--- Ciclo de Vida: Invocado al recargar (prl) o apagar (poff)
--- ============================================================================
function PluginShutdown()
    log(">>> Apagando RS Hekili...")
    pcall(function() Event.ServerLogic.Unsubscribe(UPDATE_KEY) end)
    HUD.Destroy()
    UI.Shutdown()
    Engine.Shutdown()
    log(">>> RS Hekili apagado limpiamente.")
end
