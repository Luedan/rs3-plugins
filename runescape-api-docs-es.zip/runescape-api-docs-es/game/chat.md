# Chat

The Chat table contains functions that access and manipulate chat data.

## Requirements

To ensure safety and prevent misuse a plugin must request the [chatAccess](../core/plugin.md#pluginpermissions) permission in their manifest in order to use the Chat table's functionality.

## Enumeraciones

### ChatType

These are provided as part of the [ChatMessage](../core/events.md#chatmessage) event payload.

| Name | Value |
| --- | --- |
| GENERAL | 0 |
| MOD | 1 |
| PUBLIC | 2 |
| PRIVATE_INCOMING | 3 |
| ENGINE | 4 |
| LOGIN_LOGOUT | 5 |
| PRIVATE_OUTGOING | 6 |
| MOD_PRIVATE_INCOMING | 7 |
| FRIEND_CHAT | 9 |
| FRIEND_CHAT_NOTIFICATION | 11 |
| QUICKCHAT_PUBLIC | 17 |
| QUICKCHAT_PRIVATE_INCOMING | 18 |
| QUICKCHAT_PRIVATE_OUTGOING | 19 |
| QUICKCHAT_FRIEND_CHAT | 20 |
| GROUP_SAME_TEAM | 22 |
| QUICKCHAT_GROUP_SAME_TEAM | 23 |
| GROUP_ALL | 24 |
| QUICKCHAT_GROUP_ALL | 25 |
| SNAPSHOT_FEEDBACK | 26 |
| OBJ_EXAMINE | 27 |
| NPC_EXAMINE | 28 |
| LOC_EXAMINE | 29 |
| FRIEND_NOTIFICATION | 30 |
| IGNORE_NOTIFICATION | 31 |
| PLUGIN | 33 |
| CLANCHANNEL_AFFINED_CHAT | 41 |
| CLANCHANNEL_AFFINED_QUICKCHAT | 42 |
| CLANCHANNEL_AFFINED_NOTIFICATION | 43 |
| CLANCHANNEL_GUEST_CHAT | 44 |
| CLANCHANNEL_GUEST_QUICKCHAT | 45 |
| CLANCHANNEL_GUEST_NOTIFICATION | 46 |
| CONSOLE_ERROR | 96 |
| CONSOLE_BUFFER_REPLACE | 98 |
| CONSOLE | 99 |
| TRADE_REQUEST | 100 |
| CHALLENGE | 101 |
| ASSIST_REQUEST | 102 |
| TRADE_NOTIFICATION | 103 |
| ASSIST_NOTIFICATION | 104 |
| CLAN_CHALLENGE | 107 |
| ALLY_REQUEST | 108 |
| SPAM | 109 |
| DUNGEON_INVITE | 111 |
| CONQUEST_REGULAR_CHALLENGE | 113 |
| SYSTEM_BROADCAST | 115 |
| NPC_CHAT | 116 |
| CLAN_JOIN | 117 |
| RATED_CLAN_WAR | 118 |
| IGNORABLE_TRADE_NOTIFICATION | 119 |
| ALL_PANES | 120 |
| RAID_HIGH | 122 |
| RAID_DND | 123 |
| BROADCAST | 125 |
| WORLD_EVENT | 126 |
| MISC_BROADCAST | 127 |
| GROUPCHAT_NOTIFICATION | 128 |
| DUEL_ANY_REQUEST | 132 |
| TEMPORARY_EVENT | 133 |
| HATI_FENRIR | 134 |
| LATEST_NEWSPOST | 135 |
| MOTD | 136 |
| BROADCAST_GLOBAL | 137 |
| BROADCAST_WORLD | 138 |
| BROADCAST_FRIENDS | 139 |
| INTERFACE_OPEN | 140 |
| TIMED_EVENT | 142 |
| INTERFACE_OPEN_FILTERED | 143 |
| GROUP_IRONMAN_NOTIFICATION | 144 |
| GENERAL_LINKABLE | 145 |

## Funciones

### AddMessage

```lua
Chat.AddMessage(message : String)
```

This function adds a message to the chat window.

> **Advertencia**
> Plugin-created chat messages are visible only to the local Player Character, and are not transmitted.

> **Información**
> Chat messages created with this method are queued until the next logic update, and will trigger [Event.ChatMessage](../core/events.md#chatmessage).
> This type of these messages is always [ChatType.PLUGIN](#chattype).

| Parameter | Tipo | Descripción |
| --- | --- | --- |
| message | String | Message string that will be posted to the chat window. |

> **Ejemplo**
> ```lua
> local ghostCatchphrase = "Boo!"
> Chat.AddMessage(ghostCatchphrase)
> -- Posts "Boo!" to the local chat
> ```